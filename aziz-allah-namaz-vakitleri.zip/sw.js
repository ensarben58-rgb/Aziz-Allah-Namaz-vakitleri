const C='aziz-allah-v1';
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(['./','./index.html','./manifest.json'])).catch(()=>{}));self.skipWaiting()});
self.addEventListener('fetch',e=>{if(e.request.url.includes('aladhan'))return;e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)))});
